/* Heute im Kalender: „Als Nächstes“ und Zeitleiste (Dashboard, Wahl Fabio 24.11.2026, Mockup „Termine heute“ Runde 3 Variante A).
 * Oben eine grüne Karte mit dem laufenden oder nächsten Termin und einem Ring, der bis zum Beginn bzw. Ende herunterläuft.
 * Darunter der Tag als schlichte Liste mit roter Jetzt-Linie (nur zwischen erstem Beginn und letztem Ende). Ersetzt die frühere Tageslandschaft (Dateiname und
 * C2G_Tageslandschaft bleiben, damit Einbindung und Paket gleich bleiben).
 * Gleiche Datei in Jarvis (Resources/Tageslandschaft) und im Admin der Website (admin/js/admin-tageslandschaft.js,
 * admin/css/admin-tageslandschaft.css): beide Fassungen bitte gleich halten.
 * Alle Texte nur über textContent. Bewegung einmal beim ersten Zeichnen, aus bei „Bewegung reduzieren“.
 *
 * C2G_Tageslandschaft.zeichnen(box, {
 *   termine: [{ id, start: Minute des Tages, ende: Minute, titel, farbe: '#hex', personen: [{ kuerzel, farbe }] }],
 *   jetzt: Minute des Tages, bewegen: true|false, beiKlick: function (termin) {}
 * }) */
(function (root) {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }
  function svg(tag, attrs) {
    var n = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, String(attrs[k])); });
    return n;
  }
  function zwei(n) { return (n < 10 ? '0' : '') + n; }
  function uhr(min) { min = Math.max(0, Math.min(24 * 60, Math.round(min))); if (min === 24 * 60) return '24:00'; return zwei(Math.floor(min / 60)) + ':' + zwei(min % 60); }
  function dauerText(min) { return min >= 60 ? Math.floor(min / 60) + ' h' + (min % 60 ? ' ' + (min % 60) + ' Min' : '') : min + ' Min'; }
  function kurz(min) { return min >= 60 ? Math.floor(min / 60) + ' h' : min + '′'; }
  function art(t) { return String(t.id || '').indexOf('m:') === 0 ? 'Meeting' : 'Termin'; }

  /* Was steht oben: laufender Termin, sonst der nächste, sonst „frei“. anteil = wie voll der Ring ist (0 bis 1). */
  function fokus(termine, jetzt) {
    var lauf = termine.filter(function (t) { return t.start <= jetzt && jetzt < t.ende; })[0];
    if (lauf) return { wort: 'Gerade', titel: lauf.titel, rest: 'noch ' + dauerText(lauf.ende - jetzt), termin: lauf, ring: kurz(lauf.ende - jetzt), anteil: (lauf.ende - jetzt) / (lauf.ende - lauf.start) };
    var n = termine.filter(function (t) { return t.start > jetzt; })[0];
    if (n) return { wort: 'Als Nächstes', titel: n.titel, rest: 'in ' + dauerText(n.start - jetzt), termin: n, ring: kurz(n.start - jetzt), anteil: Math.min(1, (n.start - jetzt) / 60) };
    return { wort: termine.length ? 'Für heute' : 'Heute', titel: termine.length ? 'Alle Termine sind vorbei' : 'Heute ist frei', rest: '', termin: null, ring: '', anteil: 0 };
  }

  /* Rote Jetzt-Linie nur, solange jetzt zwischen dem Beginn des ersten und dem Ende des letzten Termins liegt (Fabio 24.11.2026) */
  function zeigtJetzt(termine, jetzt) {
    if (!termine.length) return false;
    var a = Math.min.apply(null, termine.map(function (t) { return t.start; }));
    var z = Math.max.apply(null, termine.map(function (t) { return t.ende; }));
    return a <= jetzt && jetzt < z;
  }

  function avatare(personen) {
    var a = el('span', 'tl-av');
    (personen || []).slice(0, 4).forEach(function (p) {
      var s = el('span', null, p.kuerzel);
      s.style.background = p.farbe;
      a.appendChild(s);
    });
    return a;
  }

  function zeichnen(box, opt) {
    opt = opt || {};
    var termine = (Array.isArray(opt.termine) ? opt.termine : []).filter(function (t) {
      return t && isFinite(t.start) && isFinite(t.ende) && t.ende > t.start;
    }).slice(0, 40).sort(function (x, y) { return x.start - y.start; });
    var jetzt = isFinite(opt.jetzt) ? opt.jetzt : 12 * 60;
    var klick = typeof opt.beiKlick === 'function' ? opt.beiKlick : null;
    var still = opt.bewegen === false || (root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches);

    while (box.firstChild) box.removeChild(box.firstChild);
    var wurzel = el('div', 'tl-heute');
    if ((box.clientWidth || 520) < 360) wurzel.classList.add('tl-schmal');
    box.appendChild(wurzel);

    // Fokus-Karte
    var f = fokus(termine, jetzt);
    var karte = el(f.termin ? 'button' : 'div', 'tl-fokus' + (f.termin ? '' : ' ist-frei'));
    if (f.termin) {
      karte.type = 'button';
      karte.addEventListener('click', function () { if (klick) klick(f.termin); });
      var ring = el('span', 'tl-ring');
      var U = 2 * Math.PI * 25;
      var bild = svg('svg', { viewBox: '0 0 58 58', 'aria-hidden': 'true' });
      bild.appendChild(svg('circle', { cx: 29, cy: 29, r: 25, 'class': 'tl-ring-spur' }));
      var lauf = svg('circle', { cx: 29, cy: 29, r: 25, 'class': 'tl-ring-lauf', 'stroke-dasharray': U, 'stroke-dashoffset': U * (1 - f.anteil) });
      bild.appendChild(lauf);
      ring.appendChild(bild);
      ring.appendChild(el('em', null, f.ring));
      karte.appendChild(ring);
      if (!still && typeof lauf.animate === 'function') {
        lauf.animate([{ strokeDashoffset: U }, { strokeDashoffset: U * (1 - f.anteil) }], { duration: 1200, easing: 'cubic-bezier(.2,.8,.2,1)', fill: 'backwards' });
      }
    }
    var text = el('span', 'tl-fokus-text');
    text.appendChild(el('small', null, f.wort + (f.rest ? ', ' + f.rest : '')));
    text.appendChild(el('strong', null, f.titel));
    if (f.termin) {
      var zeile = el('span', 'tl-fokus-zeile');
      zeile.appendChild(el('span', 'tl-zahl', uhr(f.termin.start) + ' – ' + uhr(f.termin.ende)));
      if (f.termin.personen && f.termin.personen.length) zeile.appendChild(avatare(f.termin.personen));
      text.appendChild(zeile);
    }
    karte.appendChild(text);
    wurzel.appendChild(karte);

    // Zeitleiste mit Jetzt-Linie
    if (!termine.length) return { fokus: f, zeilen: 0 };
    var liste = el('ol', 'tl-liste');
    var linie = !zeigtJetzt(termine, jetzt);
    function jetztLinie() {
      var li = el('li', 'tl-jetzt');
      li.setAttribute('aria-label', 'Jetzt ' + uhr(jetzt));
      li.appendChild(el('span', 'tl-zahl', uhr(jetzt)));
      li.appendChild(el('i'));
      liste.appendChild(li);
      linie = true;
    }
    termine.forEach(function (t, i) {
      if (!linie && t.start > jetzt) jetztLinie();
      var li = el('li', t.ende <= jetzt ? 'ist-vorbei' : (t.start <= jetzt ? 'ist-jetzt' : ''));
      var knopf = el('button', 'tl-zeile');
      knopf.type = 'button';
      knopf.addEventListener('click', function () { if (klick) klick(t); });
      knopf.appendChild(el('span', 'tl-zeit tl-zahl', uhr(t.start)));
      var strich = el('span', 'tl-strich');
      strich.style.background = t.farbe || '';
      knopf.appendChild(strich);
      var mitte = el('span', 'tl-mitte');
      mitte.appendChild(el('b', null, t.titel));
      mitte.appendChild(el('small', null, art(t) + ', ' + dauerText(t.ende - t.start)));
      knopf.appendChild(mitte);
      if (t.personen && t.personen.length) knopf.appendChild(avatare(t.personen));
      li.appendChild(knopf);
      liste.appendChild(li);
      if (!still && typeof li.animate === 'function') {
        li.animate([{ opacity: 0, transform: 'translateY(6px)' }, { opacity: 1, transform: 'none' }], { duration: 320, delay: 120 + i * 50, easing: 'ease-out', fill: 'backwards' });
      }
    });
    if (!linie) jetztLinie(); // letzter Termin läuft gerade: Linie unter ihm
    wurzel.appendChild(liste);
    return { fokus: f, zeilen: termine.length };
  }

  var api = { zeichnen: zeichnen, fokus: fokus, zeigtJetzt: zeigtJetzt, uhr: uhr, dauerText: dauerText };
  root.C2G_Tageslandschaft = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : this);
