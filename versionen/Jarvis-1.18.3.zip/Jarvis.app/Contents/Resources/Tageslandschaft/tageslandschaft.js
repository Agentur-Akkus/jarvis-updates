/* Tageslandschaft (Dashboard, Wahl Fabio 24.11.2026, Mockup „Termine heute“ Runde 2 Variante B).
 * Der Tag als gemalte Landschaft: Himmel von morgens rosa bis abends warm, die Sonne steht auf der aktuellen Uhrzeit,
 * die Termine stehen als Glas-Kärtchen über den Hügeln. Gleiche Datei in Jarvis (Resources/Tageslandschaft) und im
 * Admin der Website (admin/js/admin-tageslandschaft.js): beide Fassungen bitte gleich halten.
 * Alle Texte nur über textContent. Bewegung einmal beim ersten Zeichnen, aus bei „Bewegung reduzieren“.
 *
 * C2G_Tageslandschaft.zeichnen(box, {
 *   termine: [{ id, start: Minute des Tages, ende: Minute, titel, farbe: '#hex', personen: [{ kuerzel, farbe }] }],
 *   jetzt: Minute des Tages, bewegen: true|false, beiKlick: function (termin) {}
 * }) */
(function (root) {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';
  var nr = 0;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }
  function svg(tag, attrs) {
    var n = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, String(attrs[k])); });
    return n;
  }
  function zwei(n) { return (n < 10 ? '0' : '') + n; }
  function uhr(min) { min = Math.max(0, Math.min(24 * 60 - 1, Math.round(min))); return zwei(Math.floor(min / 60)) + ':' + zwei(min % 60); }
  function dauerText(min) { return min >= 60 ? Math.floor(min / 60) + ' h' + (min % 60 ? ' ' + (min % 60) + ' Min' : '') : min + ' Min'; }

  /* Achse: normal 8 bis 20 Uhr; frühere oder spätere Termine dehnen sie bis zur vollen Stunde davor bzw. danach */
  function achse(termine) {
    var a = 8 * 60, z = 20 * 60;
    termine.forEach(function (t) { a = Math.min(a, Math.floor(t.start / 60) * 60); z = Math.max(z, Math.ceil(t.ende / 60) * 60); });
    return { a: Math.max(0, a), z: Math.min(24 * 60, Math.max(z, a + 60)) };
  }

  /* Was steht oben links: laufender Termin, sonst der nächste, sonst „frei“ */
  function fokus(termine, jetzt) {
    var lauf = termine.filter(function (t) { return t.start <= jetzt && jetzt < t.ende; })[0];
    if (lauf) return { wort: 'Gerade', titel: lauf.titel, rest: 'noch ' + dauerText(lauf.ende - jetzt) };
    var n = termine.filter(function (t) { return t.start > jetzt; })[0];
    if (n) return { wort: 'Als Nächstes', titel: n.titel, rest: 'in ' + dauerText(n.start - jetzt) };
    return { wort: termine.length ? 'Für heute' : 'Heute', titel: termine.length ? 'Alle Termine sind vorbei' : 'Heute ist frei', rest: '' };
  }

  function zeichnen(box, opt) {
    opt = opt || {};
    var termine = (Array.isArray(opt.termine) ? opt.termine : []).filter(function (t) {
      return t && isFinite(t.start) && isFinite(t.ende) && t.ende > t.start;
    }).slice(0, 40).sort(function (x, y) { return x.start - y.start; });
    var jetzt = isFinite(opt.jetzt) ? opt.jetzt : 12 * 60;
    var bewegen = opt.bewegen !== false;
    var id = 'tl' + (++nr);
    var W = Math.max(260, box.clientWidth || 520), H = Math.max(260, box.clientHeight || 320);
    var ax = achse(termine);
    var x = function (m) { return 24 + (m - ax.a) / (ax.z - ax.a) * (W - 48); };
    var hor = H - 58;
    var sonneY = function (m) { var u = Math.max(0, Math.min(1, (m - ax.a) / (ax.z - ax.a))); return hor - 20 - Math.sin(u * Math.PI) * (hor - 70); };

    box.textContent = '';
    var land = el('div', 'tl-land' + (W < 420 ? ' tl-schmal' : ''));
    var bild = svg('svg', { viewBox: '0 0 ' + W + ' ' + H, preserveAspectRatio: 'none', 'aria-hidden': 'true', class: 'tl-bild' });
    var defs = svg('defs');
    var himmel = svg('linearGradient', { id: id + 'h', x1: 0, x2: 1 });
    [[0, '#f6dcc6'], [0.35, '#dcebee'], [0.7, '#e8eedf'], [0.88, '#f3d3ad'], [1, '#d9c6e0']].forEach(function (s) {
      himmel.appendChild(svg('stop', { offset: s[0], 'stop-color': s[1] }));
    });
    var aq = svg('filter', { id: id + 'a', filterUnits: 'userSpaceOnUse', x: -50, y: -50, width: W + 100, height: H + 100 });
    aq.appendChild(svg('feTurbulence', { type: 'fractalNoise', baseFrequency: 0.035, numOctaves: 3, seed: 4 }));
    aq.appendChild(svg('feDisplacementMap', { in: 'SourceGraphic', scale: 7 }));
    aq.appendChild(svg('feGaussianBlur', { stdDeviation: 0.6 }));
    var weich = svg('filter', { id: id + 'w', filterUnits: 'userSpaceOnUse', x: -50, y: -50, width: W + 100, height: H + 100 });
    weich.appendChild(svg('feGaussianBlur', { stdDeviation: 14 }));
    defs.appendChild(himmel); defs.appendChild(aq); defs.appendChild(weich);
    bild.appendChild(defs);
    bild.appendChild(svg('rect', { width: W, height: H, fill: 'url(#' + id + 'h)' }));
    // Sonnenbogen
    var d = 'M' + x(ax.a).toFixed(1) + ' ' + sonneY(ax.a).toFixed(1);
    for (var m = ax.a; m <= ax.z; m += 15) d += ' L' + x(m).toFixed(1) + ' ' + sonneY(m).toFixed(1);
    bild.appendChild(svg('path', { d: d, stroke: '#c9a46a', 'stroke-width': 1.4, 'stroke-dasharray': '2 6', fill: 'none', 'stroke-linecap': 'round' }));
    // Hügel in drei Lagen (Aquarell)
    [[6, -26, 14, -8, -22, 2, '#9cc3b5', 0.75], [24, 6, 30, 12, 20, 14, '#e7c58f', 0.7], [40, 30, 46, 34, 34, 34, '#45666a', 0.55]].forEach(function (h) {
      bild.appendChild(svg('path', {
        d: 'M0 ' + (hor + h[0]) + ' C' + W * 0.22 + ' ' + (hor + h[1]) + ' ' + W * 0.38 + ' ' + (hor + h[2]) + ' ' + W * 0.55 + ' ' + (hor + h[3]) +
          ' S' + W * 0.86 + ' ' + (hor + h[4]) + ' ' + W + ' ' + (hor + h[5]) + ' V' + H + ' H0Z',
        fill: h[6], opacity: h[7], filter: 'url(#' + id + 'a)'
      }));
    });
    land.appendChild(bild);

    // Sonne auf „jetzt“ (liegt unter den Kärtchen)
    var sx = x(Math.max(ax.a, Math.min(ax.z, jetzt))), sy = sonneY(jetzt);
    var sonne = svg('svg', { viewBox: '0 0 ' + W + ' ' + H, preserveAspectRatio: 'none', 'aria-hidden': 'true', class: 'tl-bild' });
    var g = svg('g');
    g.appendChild(svg('circle', { cx: sx, cy: sy, r: 30, fill: '#f6c46a', opacity: 0.45, filter: 'url(#' + id + 'w)' }));
    g.appendChild(svg('circle', { cx: sx, cy: sy, r: 12, fill: '#f3b54a', stroke: '#fff', 'stroke-width': 3 }));
    sonne.appendChild(g);
    land.appendChild(sonne);

    // Stunden unten
    for (var st = Math.ceil(ax.a / 240) * 240; st <= ax.z; st += 240) {
      var u = el('span', 'tl-stunde', (st / 60) + ' Uhr');
      u.style.left = x(st) + 'px';
      land.appendChild(u);
    }

    // Oben links: laufend, nächster oder frei
    var f = fokus(termine, jetzt);
    var kopf = el('div', 'tl-kopf');
    kopf.appendChild(el('span', 'tl-wort', f.wort));
    kopf.appendChild(el('strong', 'tl-titel', f.titel));
    if (f.rest) kopf.appendChild(el('span', 'tl-rest', f.rest));
    land.appendChild(kopf);

    // Kärtchen: erst einsetzen, dann messen und in Reihen legen, damit sich nichts überdeckt
    var chips = termine.map(function (t, i) {
      var c = el('button', 'tl-chip');
      c.type = 'button';
      if (t.ende <= jetzt) c.classList.add('ist-vorbei');
      else if (t.start <= jetzt) c.classList.add('ist-jetzt');
      c.style.borderLeftColor = t.farbe || '#2f8f6f';
      c.appendChild(el('b', '', t.titel));
      var z = el('span', 'tl-zeile');
      z.appendChild(el('small', '', uhr(t.start)));
      var pers = (Array.isArray(t.personen) ? t.personen : []).slice(0, 4);
      if (pers.length) {
        var av = el('span', 'tl-av');
        pers.forEach(function (p) { var s = el('span', '', String(p.kuerzel || '?').slice(0, 2)); s.style.background = p.farbe || '#45666a'; av.appendChild(s); });
        z.appendChild(av);
      }
      c.appendChild(z);
      c.setAttribute('aria-label', uhr(t.start) + ' bis ' + uhr(t.ende) + ': ' + t.titel);
      if (typeof opt.beiKlick === 'function') c.addEventListener('click', function () { opt.beiKlick(t); });
      land.appendChild(c);
      return { c: c, t: t, i: i };
    });
    box.appendChild(land);

    var oben = kopf.offsetTop + kopf.offsetHeight + 10, zeilenH = 0, reihen = [];
    chips.forEach(function (k) { zeilenH = Math.max(zeilenH, k.c.offsetHeight); });
    zeilenH += 6;
    var platz = Math.max(1, Math.floor((hor + 26 - oben) / zeilenH));
    chips.forEach(function (k) {
      var w = k.c.offsetWidth, mitte = x((k.t.start + k.t.ende) / 2);
      var links = Math.max(8, Math.min(W - w - 8, mitte - w / 2));
      var r = 0;
      while (r < reihen.length && reihen[r] > links - 6) r++;
      if (r >= platz) { r = 0; for (var j = 1; j < reihen.length; j++) if (reihen[j] < reihen[r]) r = j; }
      reihen[r] = links + w;
      k.c.style.left = links + 'px';
      k.c.style.top = (oben + r * zeilenH) + 'px';
      var stiel = el('span', 'tl-stiel');
      stiel.style.left = mitte + 'px';
      stiel.style.top = (oben + r * zeilenH + k.c.offsetHeight) + 'px';
      stiel.style.height = Math.max(0, hor - (oben + r * zeilenH + k.c.offsetHeight)) + 'px';
      land.insertBefore(stiel, k.c);
    });

    // Eine Bewegung beim ersten Zeichnen: Sonne geht auf, Kärtchen stellen sich hin
    var still = !bewegen || (root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches);
    if (!still && typeof g.animate === 'function') {
      g.animate([{ transform: 'translate(' + (x(ax.a) - sx) + 'px,' + (hor - sy + 20) + 'px)', opacity: 0 }, { transform: 'none', opacity: 1 }],
        { duration: 1600, easing: 'cubic-bezier(.25,.8,.25,1)', fill: 'both' });
      chips.forEach(function (k) {
        k.c.animate([{ opacity: 0, transform: 'translateY(12px)' }, { opacity: k.c.classList.contains('ist-vorbei') ? 0.5 : 1, transform: 'none' }],
          { duration: 500, delay: 600 + k.i * 90, easing: 'cubic-bezier(.3,1.3,.5,1)', fill: 'backwards' });
      });
    }
    return { fokus: f, reihen: reihen.length, achse: ax };
  }

  var api = { zeichnen: zeichnen, achse: achse, fokus: fokus, uhr: uhr, dauerText: dauerText };
  root.C2G_Tageslandschaft = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : this);
