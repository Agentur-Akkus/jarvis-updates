#!/bin/bash
# Installiert Jarvis auf diesem Mac (Doppelklick). Kein Passwort nötig.
cd "$(dirname "$0")" || exit 1
clear
echo "=============================="
echo "   Jarvis wird installiert"
echo "=============================="
echo

warten() { [ -z "$JARVIS_OHNE_WARTEN" ] && { echo; read -r -p "Zum Beenden Enter drücken ..."; }; }

# 1. Passt dieser Mac?
if [ "$(uname -m)" != "arm64" ]; then
  echo "Dieser Mac hat keinen Apple-Chip (M1 oder neuer)."
  echo "Jarvis läuft darauf leider nicht."
  warten; exit 1
fi
HAUPT="$(sw_vers -productVersion | cut -d. -f1)"
if [ "$HAUPT" -lt 13 ]; then
  echo "Dieser Mac hat macOS $(sw_vers -productVersion). Jarvis braucht macOS 13 oder neuer."
  warten; exit 1
fi
if [ ! -d "Jarvis.app" ]; then
  echo "Jarvis.app liegt nicht neben diesem Programm."
  echo "Bitte den ganzen Ordner aus dem ZIP entpacken und von dort starten."
  warten; exit 1
fi

# 2. Läuft Jarvis schon? Dann beenden.
if pgrep -x Jarvis >/dev/null 2>&1; then
  echo "Jarvis läuft noch und wird beendet ..."
  osascript -e 'tell application "Jarvis" to quit' >/dev/null 2>&1
  sleep 2
  pkill -x Jarvis >/dev/null 2>&1
fi

# 3. Kopieren (nach Programme, sonst in den Ordner Programme des Benutzers)
ZIEL="${JARVIS_ZIEL:-/Applications}"
if [ ! -w "$ZIEL" ]; then
  ZIEL="$HOME/Applications"
  mkdir -p "$ZIEL"
  echo "Hinweis: Jarvis wird in $ZIEL installiert (Programme ist für dich gesperrt)."
fi
ALT="$ZIEL/Jarvis.app"
if [ -e "$ALT" ]; then
  # Neuere macOS-Versionen verbieten dem Terminal oft, eine schon installierte App zu löschen ("Operation not permitted"). Der Finder darf es.
  if ! rm -rf "$ALT" 2>/dev/null; then
    echo "Die alte Jarvis lässt sich nicht direkt löschen. Sie wird über den Finder in den Papierkorb gelegt ..."
    osascript -e "tell application \"Finder\" to delete POSIX file \"$ALT\"" >/dev/null 2>&1
    sleep 2
  fi
  if [ -e "$ALT" ]; then
    echo
    echo "Die alte Jarvis konnte nicht entfernt werden. Bitte von Hand:"
    echo "  1. Finder öffnen, links auf „Programme“ klicken."
    echo "  2. Jarvis in den Papierkorb ziehen (falls gefragt: Mac-Passwort eingeben)."
    echo "  3. Diese Datei (Installieren.command) noch einmal starten."
    warten; exit 1
  fi
fi
if ! ditto "Jarvis.app" "$ZIEL/Jarvis.app"; then
  echo "Kopieren hat nicht geklappt."
  warten; exit 1
fi

# 4. Download-Markierung entfernen (sonst kommt eine Sicherheitswarnung)
xattr -dr com.apple.quarantine "$ZIEL/Jarvis.app" 2>/dev/null

echo "Fertig: $ZIEL/Jarvis.app"
echo
echo "Nächste Schritte:"
echo "  1. Jarvis öffnet sich gleich."
echo "  2. Dort das Sprachmodell laden (einmalig, 1,6 GB)."
echo "  3. Die Freigaben setzen (Mikrofon, Bedienungshilfen)."
echo "  Die Anleitung (PDF) erklärt alles in Ruhe."
[ -z "$JARVIS_NICHT_STARTEN" ] && open "$ZIEL/Jarvis.app"
warten
