#!/bin/bash
# Installiert Jarvis auf diesem Mac (Doppelklick). Kein Passwort nötig.
cd "$(dirname "$0")" || exit 1
clear
echo "=============================="
echo "   Jarvis wird installiert"
echo "=============================="
echo

warten() { [ -z "$JARVIS_OHNE_WARTEN" ] && { echo; read -r -p "Zum Beenden Enter drücken ..."; }; }

# 1. Passt dieser Mac?
if [ "$(uname -m)" != "arm64" ]; then
  echo "Dieser Mac hat keinen Apple-Chip (M1 oder neuer)."
  echo "Jarvis läuft darauf leider nicht."
  warten; exit 1
fi
HAUPT="$(sw_vers -productVersion | cut -d. -f1)"
if [ "$HAUPT" -lt 14 ]; then
  echo "Dieser Mac hat macOS $(sw_vers -productVersion). Jarvis braucht macOS 14 (Sonoma) oder neuer."
  warten; exit 1
fi
if [ ! -d "Jarvis.app" ]; then
  echo "Jarvis.app liegt nicht neben diesem Programm."
  echo "Bitte den ganzen Ordner aus dem ZIP entpacken und von dort starten."
  warten; exit 1
fi

# 2. Läuft Jarvis schon? Dann beenden.
if pgrep -x Jarvis >/dev/null 2>&1; then
  echo "Jarvis läuft noch und wird beendet ..."
  osascript -e 'tell application "Jarvis" to quit' >/dev/null 2>&1
  sleep 2
  pkill -x Jarvis >/dev/null 2>&1
fi

# 2b. Sicherung, bevor etwas ersetzt wird: Protokolle, Berichte, unfertige Aufnahmen und Einstellungen.
#     Gelöscht wird dabei nichts. Die Modelle (1,9 GB) bleiben, wo sie sind, und werden weiter benutzt.
#     Anmeldung (Schlüsselbund) und Freigaben bleiben ebenfalls.
sichern() {
  local AS="$HOME/Library/Application Support/Jarvis" PO SICH
  PO="$(defaults read de.cico.jarvis protokollOrdner 2>/dev/null)"
  if [ -z "$PO" ]; then
    if [ -d "$HOME/cd_" ]; then PO="$HOME/cd_/Protokolle"; else PO="$HOME/Documents/Jarvis Protokolle"; fi
  fi
  [ -d "$AS" ] || [ -d "$PO" ] || defaults read de.cico.jarvis >/dev/null 2>&1 || return 0   # erste Installation: nichts zu sichern
  SICH="$HOME/Documents/Jarvis-Sicherung/$(date +%Y-%m-%d_%H-%M-%S)"
  mkdir -p "$SICH" || return 1
  if [ -d "$AS" ]; then rsync -a --exclude 'Modelle/' "$AS/" "$SICH/Jarvis-Daten/" || return 1; fi
  if [ -d "$PO" ]; then rsync -a --exclude 'Jarvis-Sicherung/' "$PO/" "$SICH/Protokolle/" || return 1; fi
  defaults export de.cico.jarvis "$SICH/Einstellungen.plist" >/dev/null 2>&1
  echo "Sicherung angelegt: $SICH"
  echo "  (Protokolle, Berichte, Aufnahmen und Einstellungen. Nichts wurde gelöscht.)"
}
if [ -z "$JARVIS_OHNE_SICHERUNG" ]; then
  if ! sichern; then
    echo "Die Sicherung hat nicht geklappt (voller Speicher?). Es wurde nichts verändert."
    warten; exit 1
  fi
fi

# 3. Kopieren (nach Programme, sonst in den Ordner Programme des Benutzers)
ZIEL="${JARVIS_ZIEL:-/Applications}"
if [ ! -w "$ZIEL" ]; then
  ZIEL="$HOME/Applications"
  mkdir -p "$ZIEL"
  echo "Hinweis: Jarvis wird in $ZIEL installiert (Programme ist für dich gesperrt)."
fi
ALT="$ZIEL/Jarvis.app"
if [ -e "$ALT" ]; then
  # Neuere macOS-Versionen verbieten dem Terminal oft, eine schon installierte App zu löschen ("Operation not permitted"). Der Finder darf es.
  if ! rm -rf "$ALT" 2>/dev/null; then
    echo "Die alte Jarvis lässt sich nicht direkt löschen. Sie wird über den Finder in den Papierkorb gelegt ..."
    osascript -e "tell application \"Finder\" to delete POSIX file \"$ALT\"" >/dev/null 2>&1
    sleep 2
  fi
  if [ -e "$ALT" ]; then
    echo
    echo "Die alte Jarvis konnte nicht entfernt werden. Bitte von Hand:"
    echo "  1. Finder öffnen, links auf „Programme“ klicken."
    echo "  2. Jarvis in den Papierkorb ziehen (falls gefragt: Mac-Passwort eingeben)."
    echo "  3. Diese Datei (Installieren.command) noch einmal starten."
    warten; exit 1
  fi
fi
if ! ditto "Jarvis.app" "$ZIEL/Jarvis.app"; then
  echo "Kopieren hat nicht geklappt."
  warten; exit 1
fi

# 4. Download-Markierung entfernen (sonst kommt eine Sicherheitswarnung)
xattr -dr com.apple.quarantine "$ZIEL/Jarvis.app" 2>/dev/null

# 5. Doppelte Kopien aufräumen: jede andere Jarvis (gleiche App-Kennung) außerhalb dieses Pakets in den Papierkorb
HIER="$(pwd -P)"
mdfind "kMDItemCFBundleIdentifier == 'de.cico.jarvis'" 2>/dev/null | grep '\.app$' | while IFS= read -r a; do
  case "$a" in "$ZIEL/Jarvis.app"|"$HIER"/*) continue ;; esac
  echo "Doppelte Jarvis entfernt (Papierkorb): $a"
  osascript -e "tell application \"Finder\" to delete POSIX file \"$a\"" >/dev/null 2>&1
done

echo "Fertig: $ZIEL/Jarvis.app"
echo
echo "Nächste Schritte:"
echo "  1. Jarvis öffnet sich gleich. Mit dem Admin-Konto anmelden."
echo "  2. Fehlen die Modelle, lädt Jarvis sie von selbst (einmalig, 1,9 GB)."
echo "  3. Freigaben prüfen (Mikrofon, Bedienungshilfen, Bildschirm- & Systemaudioaufnahme)."
echo "  Protokolle, Einstellungen und Modelle von vorher sind weiter da."
[ -z "$JARVIS_NICHT_STARTEN" ] && open "$ZIEL/Jarvis.app"
warten
